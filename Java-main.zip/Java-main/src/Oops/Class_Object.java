package Oops;

public class Class_Object {
    String name = "Akbar Husain";
    public static void main(String[] args) {
        Class_Object obj = new Class_Object();
        System.out.println(obj.name);
    }
}
