package Basic;

import java.util.Date;
import Problem_solving.Student_details;

public class Date_func_package {
    public static void main(String[] args) {
        System.out.println("Current Date");
        System.out.println("------------");
        Date obj = new Date();
        System.out.println(obj);

        Student_details.main();
    }
}
