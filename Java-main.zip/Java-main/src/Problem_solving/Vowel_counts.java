package Problem_solving;

import java.util.Scanner;

public class Vowel_counts {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a single character: ");
        String us = sc.nextLine();

    }
}
